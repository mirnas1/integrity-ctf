# SIGNED:UNSAFE
import __main__

def run():
    import os
    secret = os.environ.get("SECRET_FLAG", "no_flag")
    return f"The secret flag is: {secret}"
