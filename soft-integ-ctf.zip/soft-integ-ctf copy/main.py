import os

def check_signature(plugin_code):
    lines = plugin_code.splitlines()
    if not lines:
        return False
    if lines[0].strip() == "# SIGNED:SAFE":
        return True
    return False

def load_plugin():
    flag = os.environ.get("SECRET_FLAG", "no_flag")

    if not os.path.exists("plugin.py"):
        print("plugin.py not found. Create or place a plugin.py in the same directory.")
        return

    with open("plugin.py", "r", encoding="utf-8") as f:
        plugin_code = f.read()

    if check_signature(plugin_code):
        try:
            plugin_namespace = {}
            exec(plugin_code, plugin_namespace)
            if "run" in plugin_namespace:
                output = plugin_namespace["run"]()
                print("Plugin run output:", output)
            else:
                print("Plugin does not define a run() function.")
        except Exception as e:
            print("Error running plugin:", e)
    else:
        print("Plugin signature invalid! Execution blocked.")

if __name__ == "__main__":
    import sys, os
    load_plugin()
