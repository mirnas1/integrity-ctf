# SIGNED:UNSAFE

def run():
    secret = os.environ.get("SECRET_FLAG", "no_flag")
    return f"The secret flag is: {secret}"
