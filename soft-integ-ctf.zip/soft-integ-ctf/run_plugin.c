#include <stdlib.h>
#include <unistd.h>

int main() {
    setenv("SECRET_FLAG", "meer{ins3cure_flag}", 1);

    execlp("python3", "python3", "main.py", (char *)NULL);

    return 1;
}
